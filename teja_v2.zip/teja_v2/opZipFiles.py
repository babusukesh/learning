import configparser
import zipfile
import os
from datetime import datetime


config = configparser.ConfigParser()
config.read('props.ini')
files = config['MAIN']['files']
output = config['MAIN']['output']


for i in os.listdir(files):
    try:
        filename = os.path.basename(i)
        temp = str(filename)
        psd = temp.split('_')[0]
        st_ob=psd[-6:]
        dt_ob = datetime.strptime(st_ob, '%d%m%y')
        str_obj = datetime.strftime(dt_ob, '%Y%m%d')
        psw = psd[-9:-6]+str_obj
        print(f'file password {psw}')
        with zipfile.ZipFile(files+i) as fp:
            fp.extractall(path = output, pwd=bytes(psw, 'utf-8'))
        print(f'Extraction of {i} completed and saved in {output}')
    except Exception as e:
        print(f'Extraction of {i} failed with following error:\n{e}')


# for i in op:
#     with zipfile.ZipFile(i[0]) as fp:
#         fp.extractall(path = output, pwd=bytes(i[1], 'utf-8'))


# import patoolib
# patoolib.extract_archive("2021.rar")
# # (op, err) = proc.communicate()
# # print(op)
# # print(err)