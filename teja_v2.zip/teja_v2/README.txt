REQUIRED DETAILS
Provide input file location to files key in property file(props.ini) and add slash at the end
Provide output file location to output key in property file and add slash at the end
Example: C:\Users\Babu\Desktop\ziptest\

HOW TO RUN
Make sure you provided required details in property file.
Open command prompt and navigate to location where executable is present.
Give following command and press enter
	opZipFiles.exe